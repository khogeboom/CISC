//
// Created by Kasey Hogeboom on 12/16/21.
//

#ifndef FINALLAB_TANKER_H
#define FINALLAB_TANKER_H
#include "Truck.h"


class Tanker : public Truck {
    public:
        Tanker(string, int);
        void print();
};


#endif //FINALLAB_TANKER_H
